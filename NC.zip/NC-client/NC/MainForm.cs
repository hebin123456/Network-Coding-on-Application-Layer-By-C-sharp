﻿/*
 * 由SharpDevelop创建。
 * 用户： 以夕阳落款
 * 日期: 2017/3/22
 * 时间: 20:18
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using System.Web;

namespace NC
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		
		// 域名
		private string domain = string.Empty;
		
		private int Length;
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			this.domain = textBox1.Text;
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		private void TextBox1Click(object sender, EventArgs e)
		{
			OpenFileDialog open = new OpenFileDialog();
			if(open.ShowDialog() == DialogResult.OK){
				textBox1.Text = open.FileName;
			}
		}
		
		private void Button1Click(object sender, EventArgs e)
		{
			int n = 6;
			if(!File.Exists(textBox1.Text)){
				MessageBox.Show("文件不存在！");
				return ;
			}
			string name = Path.GetFileName(textBox1.Text);
			string md5 = GetMD5HashFromFile(textBox1.Text);
			string result = uploadRequest(name, md5);
			JObject jo = JObject.Parse(result);
			//JToken jk = jo["result"];
			if(jo["result"].ToString() == "0"){
				MessageBox.Show("上传参数错误！");
				return ;
			}
			else if(jo["result"].ToString() == "1"){
				MessageBox.Show("服务器已存在此文件！");
				return ;
			}
			else if(jo["result"].ToString() == "2"){
				if(!encode(textBox1.Text)){
					MessageBox.Show("编码失败！");
					return ;
				}
				int sum = 0;
				string mappedid = jo["id"].ToString();
				MessageBox.Show(mappedid);
				for(int i = 0; i < n + 2; i++){
					string upresult = uploadFile(i + "", mappedid);
					jo = JObject.Parse(upresult);
					if(jo["result"].ToString() == "2"){
						sum += 1;
					}
					else MessageBox.Show(jo["result"].ToString());
					//File.Delete(i + "");
				}
				MessageBox.Show("总共编码" + (n + 2) + "份，成功上传" + sum + "份");
			}
		}
		
		private void Button2Click(object sender, EventArgs e)
		{
			string result = downloadRequest(textBox2.Text);
			//MessageBox.Show(result);
			//return;
			JObject jo = JObject.Parse(result);
			//JToken jk = jo["result"];
			if(jo["result"].ToString() == "0"){
				MessageBox.Show("查找参数错误！");
				return ;
			}
			else if(jo["result"].ToString() == "1"){
				MessageBox.Show("查找文件不存在！");
				return ;
			}
			else if(jo["result"].ToString() == "2"){
				SaveFileDialog sd = new SaveFileDialog();
				sd.Title = "保存到";
				sd.Filter = "所有文件(*.*)|*.*";
				//点了保存按钮进入   
				if (sd.ShowDialog() == DialogResult.OK){
					
				}
			}
			
		}
		
		// url编码
		private static string UrlEncode(string str){
            StringBuilder sb = new StringBuilder();
            byte[] byStr = System.Text.Encoding.UTF8.GetBytes(str); //默认是System.Text.Encoding.Default.GetBytes(str)
            for (int i = 0; i < byStr.Length; i++)
            {
                sb.Append(@"%" + Convert.ToString(byStr[i], 16));
            }
            
            return (sb.ToString());
        }
		
		// 获取文件的md5值
		private static string GetMD5HashFromFile(string fileName){
			try{
				FileStream file = new FileStream(fileName, FileMode.Open);
				System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
				byte[] retVal = md5.ComputeHash(file);
				file.Close();
				
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < retVal.Length; i++){
					sb.Append(retVal[i].ToString("x2"));
				}
				return sb.ToString();
			}
			catch (Exception ex){
				throw new Exception("GetMD5HashFromFile() fail,error:" + ex.Message);
			}
		}
		
		// 向网站请求上传
		private string uploadRequest(string name, string md5)
		{
			string PageStr=string.Empty;
			byte[] reqbytes=Encoding.ASCII.GetBytes(string.Format("name={0}&md5={1}", HttpUtility.UrlEncode(name), md5));
			
			// 初始化HttpWebRequest
			HttpWebRequest httpRequest = (HttpWebRequest)HttpWebRequest.Create("http://localhost/NC/uploadrequest.php");
			
			// 填报文类型
			httpRequest.Method = "POST";
			httpRequest.Timeout = 1000 * 120;
			httpRequest.ContentType = "application/x-www-form-urlencoded";
			
			httpRequest.ContentLength = reqbytes.Length;
            Stream stm = httpRequest.GetRequestStream();
            stm.Write(reqbytes, 0, reqbytes.Length);

            stm.Close();
            HttpWebResponse wr = (HttpWebResponse)httpRequest.GetResponse();
            Stream stream = wr.GetResponseStream();
            StreamReader srd= new StreamReader(stream,Encoding.GetEncoding("gb2312"));
            PageStr += srd.ReadToEnd();
            stream.Close();
            srd.Close();
            return PageStr;
		}
		
		// 上传文件的方法
		private string uploadFile(string filename, string id)
		{
			// 初始化HttpWebRequest
			HttpWebRequest httpRequest = (HttpWebRequest)HttpWebRequest.Create("http://localhost/NC/upload.php?mappedid=" + id);
			
			// 生成时间戳
			string strBoundary = "----------" + DateTime.Now.Ticks.ToString("x");
			byte[] boundaryBytes = Encoding.ASCII.GetBytes(string.Format("\r\n--{0}--\r\n", strBoundary));
			byte[] idBytes = Encoding.ASCII.GetBytes(string.Format("id={0}", id));
			
			// 填报文类型
			httpRequest.Method = "POST";
			httpRequest.Timeout = 1000 * 120;
			httpRequest.ContentType = "multipart/form-data; boundary=" + strBoundary;
			
			// 封装HTTP报文头的流
			StringBuilder sb = new StringBuilder();
			sb.Append("--");
			sb.Append(strBoundary);
			sb.Append(Environment.NewLine);
			sb.Append("Content-Disposition: form-data; name=\"");
			sb.Append("file");
			sb.Append("\"; filename=\"");
			sb.Append(filename);
			sb.Append(Environment.NewLine);
			sb.Append(Environment.NewLine);
			byte[] postHeaderBytes = Encoding.UTF8.GetBytes(sb.ToString());
			
			// 计算报文长度
			FileStream fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read);
			long length = postHeaderBytes.Length + fileStream.Length + boundaryBytes.Length;
			httpRequest.ContentLength = length;
			//fileStream.Close();
			
			// 将报文头写入流
			Stream requestStream = httpRequest.GetRequestStream();
			requestStream.Write(postHeaderBytes, 0, postHeaderBytes.Length);
			
			// 将上传文件内容写入流
			byte[] buffer = new Byte[checked((uint)Math.Min(4096, (int)fileStream.Length))];
			int bytesRead = 0;
			while((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
				requestStream.Write(buffer, 0, bytesRead);
			
			// 将报文尾部写入流
			requestStream.Write(boundaryBytes, 0, boundaryBytes.Length);
			
			// 关闭流
			requestStream.Close();
			fileStream.Close();
			
			// 获得应答报文
			HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
			Stream responseStream = httpResponse.GetResponseStream();
			StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
			string strResponse = reader.ReadToEnd();
			httpRequest.Abort();
			reader.Close();
			responseStream.Close();
			return strResponse;
		}
		
		// 向网站请求下载
		private string downloadRequest(string name)
		{
			string PageStr=string.Empty;
			byte[] reqbytes=Encoding.ASCII.GetBytes(string.Format("name={0}", name));
			
			// 初始化HttpWebRequest
			HttpWebRequest httpRequest = (HttpWebRequest)HttpWebRequest.Create("http://localhost/NC/downloadrequest.php");
			
			// 填报文类型
			httpRequest.Method = "POST";
			httpRequest.Timeout = 1000 * 120;
			httpRequest.ContentType = "application/x-www-form-urlencoded";
			
			httpRequest.ContentLength = reqbytes.Length;
            Stream stm = httpRequest.GetRequestStream();
            stm.Write(reqbytes, 0, reqbytes.Length);

            stm.Close();
            HttpWebResponse wr = (HttpWebResponse)httpRequest.GetResponse();
            Stream stream = wr.GetResponseStream();
            StreamReader srd= new StreamReader(stream,Encoding.GetEncoding("gb2312"));
            PageStr += srd.ReadToEnd();
            stream.Close();
            srd.Close();
            return PageStr;
		}
		
		Matrix mx;
		byte[,] by, by2;
		public void Button3Click(object sender, EventArgs e)
		{
			int n = 8;
			mx = new Matrix();
			by = mx.getRandomMatrix(mx.getIdentityMatrix(n));
			FileStream fs = new FileStream(textBox1.Text,FileMode.Open,FileAccess.Read);
			byte[] fbytes = new byte[(int)fs.Length];
			// 保存文件的大小
			Length = fbytes.Length;
			fs.Read(fbytes, 0, fbytes.Length);
			fs.Close();
			
			byte[,] original;
			// 以8个字节为一组编码
			if(fbytes.Length % n == 0){
				int t = fbytes.Length / n;
				original = new byte[t, n];
				for(int i = 0; i < t; i++)
					for(int j = 0; j < n; j++)
						original[i, j] = fbytes[i * n + j];
			}
			else {
				int t = fbytes.Length / n;
				original = new byte[t + 1, n];
				for(int i = 0; i < t + 1; i++)
					for(int j = 0; j < n; j++)
						if(i * n + j < fbytes.Length) original[i, j] = fbytes[i * n + j];
						else original[i, j] = 0;
			}
			
			//MessageBox.Show(original.GetLength(0) + "," + original.GetLength(1));
			//MessageBox.Show(original.GetLength(0) + "," + original.GetLength(1));
			
			byte[,] dest = mx.matrixMul(original, by);
			
			int m = dest.GetLength(0);
			byte[] changed = new byte[m * n];
			for(int i = 0; i < m; i++)
				for(int j = 0; j < n; j++)
					changed[i * n + j] = dest[i, j];
			fs = new FileStream(@"C:\Users\何彬\Desktop\coded", FileMode.Create);
 
			//将byte数组写入文件中
			fs.Write(changed, 0, changed.Length);
			//所有流类型都要关闭流，否则会出现内存泄露问题
			fs.Close();
		}
		
		public void Button4Click(object sender, EventArgs e)
		{
			int n = 8;
			by2 = mx.inverseMatrix(by);
			FileStream fs = new FileStream(@"C:\Users\何彬\Desktop\coded",FileMode.Open,FileAccess.Read);
			byte[] fbytes = new byte[(int)fs.Length];
			fs.Read(fbytes, 0, fbytes.Length);
			fs.Close();
			
			byte[,] original;
			// 以8个字节为一组编码
			int t = fbytes.Length / n;
			original = new byte[t, n];
			for(int i = 0; i < t; i++)
				for(int j = 0; j < n; j++)
					original[i, j] = fbytes[i * n + j];
			
			//MessageBox.Show(original.GetLength(0) + "," + original.GetLength(1));
			//MessageBox.Show(original.GetLength(0) + "," + original.GetLength(1));
			
			byte[,] dest = mx.matrixMul(original, by2);
			
			int m = dest.GetLength(0);
			byte[] changed = new byte[m * n];
			for(int i = 0; i < m; i++)
				for(int j = 0; j < n; j++)
					changed[i * n + j] = dest[i, j];
			fs = new FileStream(@"C:\Users\何彬\Desktop\coded.exe", FileMode.Create);
 
			//将byte数组写入文件中
			fs.Write(changed, 0, changed.Length);
			//所有流类型都要关闭流，否则会出现内存泄露问题
			fs.Close();
		}
		
		// 文件编码方式
		private bool encode(string path){
			if(!File.Exists(path)){
				MessageBox.Show("不存在此文件！");
				return false;
			}
			int n = 6;
			mx = new Matrix();
			by = mx.getRandomMatrix(mx.getIdentityMatrix(n));
			
			// 得到(n+2)*n的冗余编码矩阵
			by = mx.getRedundantRandomMatrix(by);
			
			FileStream fs = new FileStream(path,FileMode.Open,FileAccess.Read);
			byte[] fbytes = new byte[(int)fs.Length];
			fs.Read(fbytes, 0, fbytes.Length);
			fs.Close();
			
			byte[,] original;
			// 分成n块，每块存储一部分+块的顺序+块长的一部分
			if(fbytes.Length % n == 0){
				// 块长度
				int t = fbytes.Length / n;
				original = new byte[n, t + 2];
				for(int i = 0; i < n; i++){
					for(int j = 0; j < t; j++)
						original[i, j] = fbytes[i * t + j];
					original[i, t] = (byte)i;
					if(Length != 0) original[i, t + 1] = (byte)(Length % 100);
					else original[i, t + 1] = 0;
					Length /= 100;
				}
			}
			else {
				int t = fbytes.Length / n;
				original = new byte[n, t + 3];
				for(int i = 0; i < n; i++){
					for(int j = 0; j < t + 1; j++)
						if(i * t + i + j < fbytes.Length) original[i, j] = fbytes[i * t + i + j];
						else original[i, j] = 0;
					// 增加编码块的位置
					original[i, t + 1] = (byte)i;
					if(Length != 0) original[i, t + 2] = (byte)(Length % 100);
					else original[i, t + 2] = 0;
					Length /= 100;
				}
			}
			
			// 编码矩阵和元数据相乘
			byte[,] dest = mx.matrixMul(by, original);
			
			// 编码后块长度
			int blockLen = original.GetLength(1);
			
			// 编码向量 + 编码后块长度
			int Len = n + blockLen;
			
			for(int i = 0; i < n + 2; i++){
				byte[] temp = new byte[Len];
				// 保存编码向量
				for(int j = 0; j < n; j++)
					temp[j] = by[i, j];
				// 保存编码后块
				for(int j = 0; j < blockLen; j++)
					temp[j + n] = dest[i, j];
				
				fs = new FileStream(i+"", FileMode.Create);
				//将byte数组写入文件中
				fs.Write(temp, 0, temp.Length);
				//所有流类型都要关闭流，否则会出现内存泄露问题
				fs.Close();
			}
			return true;
		}
		
		private void Button5Click(object sender, EventArgs e)
		{
			if(!File.Exists(textBox1.Text)){
				MessageBox.Show("不存在此文件！");
				return ;
			}
			int n = 6;
			mx = new Matrix();
			by = mx.getRandomMatrix(mx.getIdentityMatrix(n));
			
			// 得到(n+2)*n的冗余编码矩阵
			by = mx.getRedundantRandomMatrix(by);
			
			// 输出编码矩阵
//			for(int i = 0; i < n + 2; i++){
//				for(int j = 0; j < n; j++){
//					textBox3.Text += by[i, j] + ",";
//				}
//				textBox3.Text += "\r\n";
//			}
			
			FileStream fs = new FileStream(textBox1.Text,FileMode.Open,FileAccess.Read);
			byte[] fbytes = new byte[(int)fs.Length];
			Length = fbytes.Length;
			fs.Read(fbytes, 0, fbytes.Length);
			fs.Close();
			
			byte[,] original;
			// 分成n块，每块存储一部分+块的顺序+块长的一部分
			if(fbytes.Length % n == 0){
				// 块长度
				int t = fbytes.Length / n;
				original = new byte[n, t + 2];
				for(int i = 0; i < n; i++){
					for(int j = 0; j < t; j++)
						original[i, j] = fbytes[i * t + j];
					original[i, t] = (byte)i;
					if(Length != 0) original[i, t + 1] = (byte)(Length % 100);
					else original[i, t + 1] = 0;
					Length /= 100;
				}
			}
			else {
				int t = fbytes.Length / n;
				original = new byte[n, t + 3];
				for(int i = 0; i < n; i++){
					for(int j = 0; j < t + 1; j++)
						if(i * t + i + j < fbytes.Length) original[i, j] = fbytes[i * t + i + j];
						else original[i, j] = 0;
					// 增加编码块的位置
					original[i, t + 1] = (byte)i;
					if(Length != 0) original[i, t + 2] = (byte)(Length % 100);
					else original[i, t + 2] = 0;
					Length /= 100;
				}
			}
			
			// 编码矩阵和元数据相乘
			byte[,] dest = mx.matrixMul(by, original);
			
			// 编码后块长度
			int blockLen = original.GetLength(1);
			
			// 编码向量 + 编码后块长度
			int Len = n + blockLen;
			
			for(int i = 0; i < n + 2; i++){
				byte[] temp = new byte[Len];
				// 保存编码向量
				for(int j = 0; j < n; j++)
					temp[j] = by[i, j];
				// 保存编码后块
				for(int j = 0; j < blockLen; j++)
					temp[j + n] = dest[i, j];
				
				fs = new FileStream(i+"", FileMode.Create);
				//将byte数组写入文件中
				fs.Write(temp, 0, temp.Length);
				//所有流类型都要关闭流，否则会出现内存泄露问题
				fs.Close();
			}
		}
		
		private void Button6Click(object sender, EventArgs e)
		{
			int n = 6;
			mx = new Matrix();
			Length = 0;
			FileStream fs;
			byte[,] by = new byte[n, n];
			byte[,] by2 = new byte[n, 1];
			string[] str = {"6", "1", "2", "3", "4", "5"};
			for(int i = 0; i < n; i++){
				fs = new FileStream(str[i],FileMode.Open,FileAccess.Read);
				byte[] fbytes = new byte[(int)fs.Length];
				fs.Read(fbytes, 0, fbytes.Length);
				
				if(by2.GetLength(1) != fbytes.Length - n){
					by2 = new byte[n, fbytes.Length - n];
				}
				
				// 编码后块长度
				int byteLen = by2.GetLength(1);
				
				// 恢复编码矩阵
				for(int j = 0; j < n; j++){
					by[i, j] = fbytes[j];
				}
				
				// 恢复编码后的块
				for(int j = 0; j < byteLen; j++)
					by2[i, j] = fbytes[j + n];
				
				fs.Close();
			}
			
			// 检验编码矩阵是否正确
//			for(int i = 0; i < n; i++){
//				for(int j = 0; j < n; j++){
//					textBox3.Text += by[i, j] + ",";
//				}
//				textBox3.Text += "\r\n";
//			}
			
			// 编码矩阵求逆
			by = mx.inverseMatrix(by);
			
			// 解码
			byte[,] original = mx.matrixMul(by, by2);
			
			// 解码块的长度
			int blockLen = original.GetLength(1);
			
			Dictionary<int, byte[]> dic = new Dictionary<int, byte[]>();
			for(int i = 0; i < n; i++){
				byte[] temp = new byte[blockLen - 2];
				for(int j = 0; j < blockLen - 2; j++){
					temp[j] = original[i, j];
				}
				
				if(0 == original[i, blockLen - 2]) Length += original[i, blockLen - 1];
				if(1 == original[i, blockLen - 2]) Length += original[i, blockLen - 1] * 100;
				if(2 == original[i, blockLen - 2]) Length += original[i, blockLen - 1] * 10000;
				if(3 == original[i, blockLen - 2]) Length += original[i, blockLen - 1] * 1000000;
				
				dic.Add(original[i, blockLen - 2], temp);
			}
			
			List<byte> byteSource = new List<byte>();
			for(int i = 0; i < dic.Count; i++){
				byteSource.AddRange(dic[i]);
			}
			
			byte[] data = byteSource.ToArray();
			
			data = dropTail(data);
			
			fs = new FileStream("decode", FileMode.Create);
			//将byte数组写入文件中
			fs.Write(data, 0, data.Length);
			//所有流类型都要关闭流，否则会出现内存泄露问题
			fs.Close();
		}
		
		// 去除最后的0
		private byte[] dropTail(byte[] a){
			//MessageBox.Show(Length + "," + a.Length);
			// 容错性
			if(Length > a.Length) return a;
			byte[] c = new byte[Length];
			for(int i = 0; i < Length; i++)
				c[i] = a[i];
			return c;
		}
	}
}